 //  NUMBER type
let first: number = 12.0;             // number   
let second: number = 0x37CF;          // hexadecimal  
let third: number = 0o377 ;           // octal  
let fourth: number = 0b111001;        // binary   
  
console.log(first);           // 123  
console.log(second);          // 14287  
console.log(third);           // 255  
console.log(fourth);          // 57  

// STRING
let empName: string = "Rohan";   
let empDept: string = "IT";   
  
// Before-ES6  
let output1: string = empName + " works in the " + empDept + " department.";   
  
// After-ES6  
let output2: string = `${empName} works in the ${empDept} department.`;   
  
console.log(output1);//Rohan works in the IT department.   
console.log(output2);//Rohan works in the IT department.  


//BOOLEAN
let isDone: boolean = false;  
console.log(isDone);

//VOID
let tempNum: void = undefined;  
  tempNum = null;      
  //tempNum = 123;      //Error 

//NULL - Null represents a variable whose value is undefined.
let num1: number = null;  
let bool1: boolean = null;   
let str1: string = null; 

//UNDEFINED - The Undefined primitive type denotes all uninitialized variables in TypeScript and JavaScript.
let num: number = undefined;  
let bool: boolean = undefined;  
let str: string = undefined; 

// ANY 
function ProcessData(x: any, y: any) {  
    return x + y;  
}  
let result: any;  
result = ProcessData("Hello ", "Any!"); //Hello Any!  
console.log(result);
result = ProcessData(2, 3); //5 
console.log(result);