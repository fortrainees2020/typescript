/// <reference path = "110_namespace_StringUtility.ts" />  

class Emp {
                        empCode: number;
                        empName: string;
                        constructor(name: string, code: number) {
                                    this.empName =  StringUtility.ToCapital(name);
                                    this.empCode = code;
                                }
                                displayEmployee() {
                                    console.log ("Employee Code: " + this.empCode + ", Employee Name: " + this.empName );
                                }
                }
        var e2 = new Emp("Ashu2",1);
        e2.displayEmployee();cls
        