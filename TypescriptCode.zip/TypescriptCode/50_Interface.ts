interface IEmployee {
    empCode: number;
    empName: string;
    empDept?:string;
}

let empObj1:IEmployee = {   // OK
    empCode:1,
    empName:"Steve"
}

let empObj2:IEmployee = {    // OK
    empCode:1,
    empName:"Bill",
    empDept:"IT"
}

console.log(empObj1.empCode+empObj1.empName+empObj1.empDept);
console.log(empObj2.empCode+empObj2.empName+empObj2.empDept);

