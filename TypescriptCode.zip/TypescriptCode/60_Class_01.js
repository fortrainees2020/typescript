"use strict";
var Employee1 = /** @class */ (function () {
    function Employee1(code, name) {
        this.empName = name;
        this.empCode = code;
    }
    Employee1.prototype.getSalary = function () {
        return 10000;
    };
    return Employee1;
}());
var e1 = new Employee1(1, "ashu");
console.log(e1.empCode + e1.empName + e1.getSalary());
