"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _100_Module_Employee_1 = require("./100_Module_Employee");
var empObj = new _100_Module_Employee_1.Employee("Steve Jobs", 1);
empObj.displayEmployee(); //Output: Employee Code: 1, Employee Name: Steve Jobs  
