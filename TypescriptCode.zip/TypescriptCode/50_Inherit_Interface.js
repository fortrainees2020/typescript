"use strict";
var empObj = {
    empCode: 1,
    name: "Bill",
    gender: "Male"
};
console.log(empObj.name + empObj.gender + empObj.empCode);
