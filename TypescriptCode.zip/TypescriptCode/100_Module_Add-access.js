"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _100_Module_Add_1 = require("./100_Module_Add");
var addObject = new _100_Module_Add_1.Addition(10, 20);
var subObject = new _100_Module_Add_1.Substraction(20, 10);
addObject.Sum();
subObject.Substract();
