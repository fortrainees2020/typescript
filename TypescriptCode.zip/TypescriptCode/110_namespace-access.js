"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var student_details = {
    rollNo: 4, sName: "Ashish"
};
console.log(student_details.rollNo + student_details.sName);
// Declare object for class 5
var student_details5 = {
    rollNo: 5, sName: "Ani", marks: 5, address: "Pune"
};
console.log(student_details5.rollNo + student_details5.sName, student_details5.marks + student_details5.address);
