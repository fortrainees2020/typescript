"use strict";
/// <reference path = "110_namespace_StringUtility.ts" />  
var Emp = /** @class */ (function () {
    function Emp(name, code) {
        this.empName = StringUtility.ToCapital(name);
        this.empCode = code;
    }
    Emp.prototype.displayEmployee = function () {
        console.log("Employee Code: " + this.empCode + ", Employee Name: " + this.empName);
    };
    return Emp;
}());
var e2 = new Emp("Ashu2", 1);
e2.displayEmployee();
