function add(a:string, b:string):string;

function add(a:number, b:number): number;

function add(a: any, b:any): any {
    return a + b;
}

let name1 = add("Hello ", "Steve"); // returns "Hello Steve" 
let num = add(10, 20); // returns 30 
console.log(name1);
console.log(num)
