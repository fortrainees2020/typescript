"use strict";
function Greet(greeting) {
    var names = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        names[_i - 1] = arguments[_i];
    }
    return greeting + " " + names.join(", ") + "!";
}
var g1 = Greet("Hello", "Steve", "Bill"); // returns "Hello Steve, Bill!"
console.log(g1);
var g = Greet("Hello"); // returns "Hello !
console.log(g);
