function hello() { 
    return "Hello Typescript"; 
} 
console.log('Welcome to ' +hello()); 