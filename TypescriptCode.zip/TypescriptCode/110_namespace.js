"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Declare object for class 4
/*const student_details:Four.classIv={
    rollNo:4, sName:"Ashu"
}
console.log(student_details.rollNo+student_details.sName);

// Declare object for class 5
const student_details5:Five.classV={
    rollNo:5, sName:"Ani",marks:5, address:"Pune"
}
console.log(student_details5.rollNo+student_details5.sName, student_details5.marks+student_details5.address);*/ 
