function Greet(greeting: string, ...names: string[]) {
    return greeting + " " + names.join(", ") + "!";
}

var g1=Greet("Hello", "Steve", "Bill"); // returns "Hello Steve, Bill!"
console.log(g1);

var g= Greet("Hello");// returns "Hello !
console.log(g);