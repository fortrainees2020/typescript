/// <reference path = "./110_namespace_studentCalc.ts" />  
  
let TotalFee = studentCalc.AnualFeeCalc(1500, 4);  
  
console.log("Output: " +TotalFee);  