
//Arrow function
let sum = (x: number, y: number): number => {
    return x + y;
}

var tot=sum(10, 20); //returns 
console.log("Total is :"+tot);
