import  {Addition, Substraction} from './100_Module_Add';  
  
let addObject = new Addition(10, 20);   
let subObject = new Substraction(20, 10);  
  
addObject.Sum();  
subObject.Substract();

