
/*
ES3 is default to run for ...of compile by specifying es6 script
>tsc --target es6 80_for_array.ts
>node   80_for_array
*/ 
 for (let i = 0; i < 3; i++) {
    console.log ("Block statement execution no." + i);
  }
  //for of 
  /*The for...of loop returns elements from a collection e.g. array, list or tuple, and so,
   there is no need to use the traditional for loop shown above.*/
   
   //ARRAY
   let arr = [10, 20, 30, 40];
    for (var val of arr) {
    console.log(val); // prints values: 10, 20, 30, 40
    }


    //let str1 = "Hello World";
    //for (var char of str1) {
    //console.log(char); // prints chars: H e l l o  W o r l d
    //
  //}

    let arr1 = [10, 20, 30, 40];
    for (var index in arr1) {
      console.log(index); // prints indexes: 0, 1, 2, 3
    
      console.log(arr1[index]); // prints elements: 10, 20, 30, 40
    }