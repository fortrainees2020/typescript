"use strict";
var empObj1 = {
    empCode: 1,
    empName: "Steve"
};
var empObj2 = {
    empCode: 1,
    empName: "Bill",
    empDept: "IT"
};
console.log(empObj1.empCode + empObj1.empName + empObj1.empDept);
console.log(empObj2.empCode + empObj2.empName + empObj2.empDept);
