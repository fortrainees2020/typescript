import {greeting } from "./100_ModuleA1";
console.log(greeting); //Prints Hello World!


console.log(greeting+"Typescript"); //Prints Hello Typescript 