class Employee1 {
    empCode: number;
    empName: string;

    constructor(code: number, name: string) {
            this.empName = name;
            this.empCode = code;
    }

    getSalary() : number {
        return 10000;
    }
}
let e1= new Employee1(1,"ashu");
console.log(e1.empCode+ e1.empName+e1.getSalary());