namespace Drawing { 
    export interface IShape { 
       draw(); 
    }
 }  