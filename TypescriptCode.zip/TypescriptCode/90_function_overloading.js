"use strict";
function add(a, b) {
    return a + b;
}
var name1 = add("Hello ", "Steve"); // returns "Hello Steve" 
var num = add(10, 20); // returns 30 
console.log(name1);
console.log(num);
