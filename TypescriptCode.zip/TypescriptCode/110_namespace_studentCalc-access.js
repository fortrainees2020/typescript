"use strict";
/// <reference path = "./110_namespace_studentCalc.ts" />  
var TotalFee = studentCalc.AnualFeeCalc(1500, 4);
console.log("Output: " + TotalFee);
