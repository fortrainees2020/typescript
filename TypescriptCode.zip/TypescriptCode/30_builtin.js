//  NUMBER type
var first = 12.0; // number   
var second = 0x37CF; // hexadecimal  
var third = 255; // octal  
var fourth = 57; // binary   
console.log(first); // 123  
console.log(second); // 14287  
console.log(third); // 255  
console.log(fourth); // 57  
// STRING
var empName = "Rohan";
var empDept = "IT";
// Before-ES6  
var output1 = empName + " works in the " + empDept + " department.";
// After-ES6  
var output2 = "".concat(empName, " works in the ").concat(empDept, " department.");
console.log(output1); //Rohan works in the IT department.   
console.log(output2); //Rohan works in the IT department.  
//BOOLEAN
var isDone = false;
console.log(isDone);
//VOID
var tempNum = undefined;
tempNum = null;
//tempNum = 123;      //Error 
//NULL - Null represents a variable whose value is undefined.
var num1 = null;
var bool1 = null;
var str1 = null;
//UNDEFINED - The Undefined primitive type denotes all uninitialized variables in TypeScript and JavaScript.
var num = undefined;
var bool = undefined;
var str = undefined;
// ANY 
function ProcessData(x, y) {
    return x + y;
}
var result;
result = ProcessData("Hello ", "Any!"); //Hello Any!  
console.log(result);
result = ProcessData(2, 3); //5 
console.log(result);
