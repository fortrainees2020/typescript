namespace studentCalc{  
    export function AnualFeeCalc(feeAmount: number, term: number){  
    return feeAmount * term;  
    }  
} 