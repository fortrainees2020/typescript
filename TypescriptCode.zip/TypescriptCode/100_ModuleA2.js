"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _100_ModuleA1_1 = require("./100_ModuleA1");
console.log(_100_ModuleA1_1.greeting); //Prints Hello World!
console.log(_100_ModuleA1_1.greeting + "Typescript"); //Prints Hello Typescript 
