//Arrow function
var sum = function (x, y) {
    return x + y;
};
var tot = sum(10, 20); //returns 
console.log("Total is :" + tot);
