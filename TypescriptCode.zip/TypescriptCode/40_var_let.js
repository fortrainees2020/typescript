// Var
console.log(x); //undefined
var x = 5;
console.log(x); //5
//let
console.log(x); //5
var y = 5;
console.log(y); //5
//var
function varGreeter() {
    var a = 10;
    var a = 20; //a is replaced
    console.log(a);
}
varGreeter();
//let
function LetGreeter() {
    var a1 = 10;
    // let a1 = 20; //SyntaxError: 
    //Identifier 'a' has already been declared
    console.log(a1);
}
LetGreeter();
//HOISTING
function hoist() {
    x = 20;
    var y = 100;
}
hoist();
console.log("x=" + x);
console.log("y=" + y);
